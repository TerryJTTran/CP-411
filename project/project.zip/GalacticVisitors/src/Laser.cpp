#include "Laser.hpp"
#include <stdio.h>

Laser::Laser()
{
	//Layer 1
	cube[0] =  new Cube();
	cube[0]->setParentMC(&mc);
	cube[0]->translate(0,1, 7);


	//Layer 2
	cube[1] =  new Cube();
	cube[1]->setParentMC(&mc);
	cube[1]->translate(0,0, 6);

	//Layer 3
	cube[2] =  new Cube();
	cube[2]->setParentMC(&mc);
	cube[2]->translate(0,-1, 5);

	//Layer 4
	cube[3] =  new Cube();
	cube[3]->setParentMC(&mc);
	cube[3]->translate(0,0, 4);

	//Layer 5
	cube[4] =  new Cube();
	cube[4]->setParentMC(&mc);
	cube[4]->translate(0,1, 3);


	//Layer 6
	cube[5] =  new Cube();
	cube[5]->setParentMC(&mc);
	cube[5]->translate(0,0, 2);

	//Layer 7
	cube[6] =  new Cube();
	cube[6]->setParentMC(&mc);
	cube[6]->translate(0,-1, 1);

	for(int i = 0; i < 7; i++){
			cube[i]->setFaceColor(0, 1.0, 1.0);
		}

	counter = 0;
}

Laser::~Laser()
{
	for(int i = 0; i < 7; i++){
		delete cube[i];
	}

}

void Laser::draw()
{
	for(int i = 0; i < 7; i++){
	    glPushMatrix();
	    this->ctmMultiply();
		glScalef(s, s, s);
		cube[i]->draw();
		glPopMatrix();
	}

}

void Laser::changeForm(){
	if(counter == 0){
		cube[0]->translate(0,-2, 0);
		cube[2]->translate(0,2, 0);
		cube[4]->translate(0,-2, 0);
		cube[6]->translate(0,2, 0);
		counter = 1;
	}
	else{
		cube[0]->translate(0,2, 0);
		cube[2]->translate(0,-2, 0);
		cube[4]->translate(0,2, 0);
		cube[6]->translate(0,-2, 0);
		counter = 0;
	}
}
