#include "World.hpp"
#include "Cube.hpp"

#include "Alien.hpp"
#include "Alien2.hpp"
#include "Alien3.hpp"
#include "Tank.hpp"
#include "Bullet.hpp"
#include "Explosion.hpp"
#include "Laser.hpp"

using namespace std;

World::World() {
	Shape *obj = NULL;

	//Makes all aliens and places them in starting row positions
	for (int i = 0; i < 22; i++){
		obj = new Alien();
		obj->setId(i);
		obj->translate(0, -3.5 + (0.7*(i%11)), 3.25 + ((i/11)*0.5));
		obj->scaleChange(-0.96);
		objlist.push_back(obj);
	}

	for (int i = 22; i < 33; i++){
			obj = new Alien3();
			obj->setId(i);
			obj->translate(0, -3.5 + (0.7*(i%11)), 3.25 + ((i/11)*0.5));
			obj->scaleChange(-0.96);
			objlist.push_back(obj);
		}

	for (int i = 33; i < 44; i++){
			obj = new Alien2();
			obj->setId(i);
			obj->translate(0, -3.5 + (0.7*(i%11)), 3.25 + ((i/11)*0.5));
			obj->scaleChange(-0.96);
			objlist.push_back(obj);
	}

	//Spawns player tank
	obj = new Tank();
	obj->setId(44);
	obj->translate(0, 0, -2.5);
	obj->scaleChange(-0.96);
	objlist.push_back(obj);


}

void World::createBullet(){
	Shape *obj = new Bullet();
	Shape *tank = searchById(44);
	obj->setId(45);
	obj->translate(tank->getMC().mat[0][3], tank->getMC().mat[1][3], tank->getMC().mat[2][3]);
	obj->scaleChange(-0.96);
	objlist.push_back(obj);

}

void World::createExplosion(int x, Shape *source){
	Shape *obj = new Explosion();
	obj->setId(x);
	obj->translate(source->getMC().mat[0][3], source->getMC().mat[1][3], source->getMC().mat[2][3]);
	obj->scaleChange(-0.96);
	objlist.push_back(obj);

}

void World::createLaser(int x){
	Shape *obj = new Laser();
	Shape *alien = searchById(x);
	obj->setId(47);
	obj->translate(alien->getMC().mat[0][3], alien->getMC().mat[1][3], alien->getMC().mat[2][3]);
	obj->scaleChange(-0.96);
	objlist.push_back(obj);

}

World::~World(){
	Shape *obj;
	while (!objlist.empty()) {
		obj = objlist.front();
		objlist.pop_front();
		free(obj);
	}
}

void lineSegment(float x1, float y1, float z1, float x2, float y2, float z2) {
	glBegin(GL_LINES);
	glVertex3f(x1, y1, z1);
	glVertex3f(x2, y2, z2);
	glEnd();
}

void World::draw() {
	std::list<Shape*>::iterator it;
	for (it = objlist.begin(); it !=  objlist.end(); ++it) {
	  (*it)->draw();
    }
}

void World::reset(){


	std::list<Shape*>::iterator it;
	for (it = objlist.begin(); it !=  objlist.end(); ++it) {
	  (*it)->reset();
	  (*it)->setScale(0.2);

  }
}

Shape* World::searchById(GLint i) {
	std::list<Shape*>::iterator it;
	for (it = objlist.begin(); it !=  objlist.end(); ++it) {
	  if ((*it)->getId() == i) return *it;
    }
	return NULL;
}

