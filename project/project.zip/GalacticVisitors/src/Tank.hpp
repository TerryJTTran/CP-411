/*
 * Tank.hpp
 *
 *  Created on: 2021 Dec 1
 *      Author: Terry
 */

#ifndef SRC_TANK_HPP_
#define SRC_TANK_HPP_


#include <GL/glut.h>

#include "Cube.hpp"


class Tank: public Shape{
protected:
	Cube* cube[38];
public:
	~Tank();
	Tank();
	void draw();
	void changeForm();
};

#endif /* SRC_TANK_HPP_ */
