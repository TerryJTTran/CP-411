/*
 * Alien.hpp
 *
 *  Created on: 2021 Dec 1
 *      Author: Terry
 */

#ifndef SRC_ALIEN_HPP_
#define SRC_ALIEN_HPP_

#include <GL/glut.h>

#include "Cube.hpp"


class Alien: public Shape{
protected:
	Cube* cube[46];
	int counter;
public:
	~Alien();
	Alien();
	void draw();
	void changeForm();
};
#endif
