#include <windows.h>  // for playing sound
#include <mmsystem.h> //

#include "Animation.hpp"
#include "World.hpp"
#include <stdlib.h>
#include "time.h"
#include <cstdlib>
#include <ctime>

int oldTime = clock();
int remainingAliens = 44;
int speed = 500;
int carry = 0;
int carrybullet = 0;
int carrylaser = 0;
int drop = 0;
int direction = 1;
int lmAlien = 33;
int rmAlien = 43;
int bmAliens[11] = {0,1,2,3,4,5,6,7,8,9,10};

extern Shape* selectObj;
extern World myWorld;

void tankAction(int action){
	Shape *tank = myWorld.searchById(44);
	Shape *bullet = myWorld.searchById(45);
	Shape *Explosion = myWorld.searchById(46);
	if(action == -1 && tank->getMC().mat[1][3] > -5){//Left
		tank->translate(0, -0.075, 0);
	}
	else if(action == 1 && tank->getMC().mat[1][3] < 5){//Right
		tank->translate(0, 0.075, 0);
	}
	else if(action == 0 && bullet == NULL && Explosion == NULL){//Shoot
		myWorld.createBullet();
		PlaySound((LPCSTR) "shoot.wav", NULL, SND_FILENAME | SND_ASYNC);
	}
    glutPostRedisplay();
}

void gameStart(void){
	selectObj = NULL;
	int newTime = clock();
	srand(time(NULL));

	//Animation Bullet
	Shape *bullet = myWorld.searchById(45);
	if(newTime - oldTime + carrybullet >= 5){

		if(bullet != NULL){
				bullet->translate(0, 0, 0.1);
				if(bullet->getMC().mat[2][3] > 5.5){
					myWorld.createExplosion(46, bullet);
					myWorld.objlist.remove(bullet);
				}


				//Collision check
				else{
					std::list<Shape*>::iterator it;
					for (it = myWorld.objlist.begin(); it !=  myWorld.objlist.end(); ++it) {
					  if((*it)->getId() != 44 && (*it) != bullet && bullet->getMC().mat[1][3] <= (*it)->getMC().mat[1][3] + 0.2 && bullet->getMC().mat[1][3] >= (*it)->getMC().mat[1][3] - 0.2 && bullet->getMC().mat[2][3] <= (*it)->getMC().mat[2][3] + 0.2 && bullet->getMC().mat[2][3] >= (*it)->getMC().mat[2][3] - 0.2){
							myWorld.createExplosion(46, bullet);
							PlaySound((LPCSTR) "invaderkilled.wav", NULL, SND_FILENAME | SND_ASYNC);
							Shape *alien = myWorld.searchById((*it)->getId());
							myWorld.objlist.remove(bullet);
							myWorld.objlist.remove(alien);
							remainingAliens -= 1;
							break;
					  }

				  }
				}
				carrybullet = 0;
			}
		}

		else{
			carrybullet += newTime - oldTime;
		}

	//Still aliens alive
	if(remainingAliens != 0){

		//Alien laser
		Shape *laser = myWorld.searchById(47);
		if(newTime - oldTime + carrylaser >= 30){

			if(laser != NULL){
					laser->translate(0, 0, -0.1);
					laser->changeForm();
					//Border
					if(laser->getMC().mat[2][3] < -2.5){
						myWorld.createExplosion(48, laser);
						myWorld.objlist.remove(laser);
					}


					//Collision check
					else{
						Shape *tank = myWorld.searchById(44);
						if(laser->getMC().mat[1][3] <= tank->getMC().mat[1][3] + 0.2 && laser->getMC().mat[1][3] >= tank->getMC().mat[1][3] - 0.2 && laser->getMC().mat[2][3] <= tank->getMC().mat[2][3] + 0.2 && laser->getMC().mat[2][3] >= tank->getMC().mat[2][3] - 0.2){
							myWorld.createExplosion(48, laser);
							PlaySound((LPCSTR) "explosion.wav", NULL, SND_FILENAME | SND_ASYNC);
							myWorld.objlist.remove(laser);
							myWorld.objlist.remove(tank);
							exit(0);
						}

					}
					carrylaser = 0;
				}
			else{
				//Select random alien in bottom
				int x = rand() % 10;
				while(myWorld.searchById(bmAliens[x]) == NULL){
					x = rand() % 10;
				}

				//Generate laser
					myWorld.createLaser(bmAliens[x]);
				}
			}

			else{
				carrylaser += newTime - oldTime;
			}


		if(newTime - oldTime + carry >= speed){

			//Remove explosion
			Shape *ExplosionB = myWorld.searchById(46);
			Shape *ExplosionL = myWorld.searchById(48);
			if(ExplosionB != NULL){
				myWorld.objlist.remove(ExplosionB);
			}
			if(ExplosionL != NULL){
				myWorld.objlist.remove(ExplosionL);
			}

		//Find bottom row of aliens
		for (int i = 0; i < 11; i++){
			Shape *bottom = myWorld.searchById(bmAliens[i]);
			if(bottom == NULL){
				for(int j = 10; j < 40; j+=10){
					bottom = myWorld.searchById(bmAliens[i]+j);
					if(bottom != NULL){
						bmAliens[i] = bmAliens[i]+j;
						j = 40;
					}
				}
			}
		}

		//Find left and right most alien
		Shape *left = myWorld.searchById(lmAlien);
		Shape *right = myWorld.searchById(rmAlien);
		if(left == NULL || right == NULL){
			for(int i = 0; i < 44; i++){
				Shape *check = myWorld.searchById(i);
				if(check != NULL){
					if(left == NULL){
						lmAlien = i;
						left = myWorld.searchById(lmAlien);
					}
					else if(check->getMC().mat[1][3] < left->getMC().mat[1][3]){
						lmAlien = i;
						left = myWorld.searchById(lmAlien);
					}
					if(right == NULL){
						rmAlien = i;
						right = myWorld.searchById(rmAlien);
					}
					else if(check->getMC().mat[1][3] > right->getMC().mat[1][3]){
						rmAlien = i;
						right = myWorld.searchById(rmAlien);

					}
				}
			}

		}

		//Set direction
		if(direction > 0 && right->getMC().mat[1][3] > 5){//Right
			direction = -1;
			drop = 1;
		}
		else if(direction < 0 && left->getMC().mat[1][3] < -5){//Left
			direction = 1;
			drop = 1;
		}

		//Animation Alien

			for (int i = 0; i < 44; i++){
				Shape *alien = myWorld.searchById(i);
				if(alien != NULL){
					alien->changeForm();
					if(drop == 1){
						if(alien->getMC().mat[2][3] <= -2.5){
							exit(0);
						}
						alien->translate(0, 0, -0.25);
					}
					else{
						alien->translate(0, 0.2*direction, 0);
					}
				}
			}

			drop = 0;
			if(remainingAliens < 2 && speed != 50){
				speed = 50;
				PlaySound((LPCSTR) "fastinvader1.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
			else if(remainingAliens < 4 && speed != 100){
				speed = 100;
			}
			else if(remainingAliens < 11 && speed != 150){
				speed = 150;
				PlaySound((LPCSTR) "fastinvader2.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
			else if (remainingAliens < 22 && speed != 200){
				speed = 200;
				}
			else if(remainingAliens < 32 && speed != 300){
				speed = 300;
				PlaySound((LPCSTR) "fastinvader3.wav", NULL, SND_FILENAME | SND_ASYNC);

			}
			else if(remainingAliens < 42 && speed != 499){
				PlaySound((LPCSTR) "fastinvader4.wav", NULL, SND_FILENAME | SND_ASYNC);
			}
			carry = 0;
		}
		else{
			carry += newTime - oldTime;
		}

		oldTime = newTime;
	}
	else{//Win case
		exit(0);
	}
	glutPostRedisplay();
}
