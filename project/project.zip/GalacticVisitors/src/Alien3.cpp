/*
 * Alien3.cpp
 *
 *  Created on: 2021 Dec 7
 *      Author: Terry
 */



#include "Alien3.hpp"
#include <stdio.h>


Alien3::Alien3()
{
	//Layer 1
	for (int i = 0; i < 5; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-2, 8);
	}

	//Layer 2
	for (int i = 5; i < 16; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-10, 7);
	}

	//Layer 3
	for (int i = 16; i < 29; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-22, 6);
	}

	//Layer 4
	for (int i = 29; i < 32; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-35, 5);
	}

	for (int i = 32; i < 35; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-33, 5);
	}

	for (int i = 35; i < 38; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-31, 5);
	}

	//Layer 5
	for (int i = 38; i < 51; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-44, 4);
	}

	//Layer 6
		cube[51] =  new Cube();
		cube[51]->setParentMC(&mc);
		cube[51]->translate(0,-3, 3);

		cube[52] =  new Cube();
		cube[52]->setParentMC(&mc);
		cube[52]->translate(0,-2, 3);

		cube[53] =  new Cube();
		cube[53]->setParentMC(&mc);
		cube[53]->translate(0,2, 3);

		cube[54] =  new Cube();
		cube[54]->setParentMC(&mc);
		cube[54]->translate(0,3, 3);

	//Layer 7
		cube[55] =  new Cube();
		cube[55]->setParentMC(&mc);
		cube[55]->translate(0,-4, 2);

		cube[56] =  new Cube();
		cube[56]->setParentMC(&mc);
		cube[56]->translate(0,-1, 2);

		cube[57] =  new Cube();
		cube[57]->setParentMC(&mc);
		cube[57]->translate(0,0, 2);

		cube[58] =  new Cube();
		cube[58]->setParentMC(&mc);
		cube[58]->translate(0,1, 2);

		cube[59] =  new Cube();
		cube[59]->setParentMC(&mc);
		cube[59]->translate(0,4, 2);


	//Layer 8
		cube[60] =  new Cube();
		cube[60]->setParentMC(&mc);
		cube[60]->translate(0,-3, 1);

		cube[61] =  new Cube();
		cube[61]->setParentMC(&mc);
		cube[61]->translate(0,3, 1);


	for(int i = 0; i < 62; i++){
			cube[i]->setFaceColor(0.5, 1.0, 0);
		}

	counter = 0;
}

Alien3::~Alien3()
{
	for(int i = 0; i < 62; i++){
		delete cube[i];
	}

	counter = 0;

}



void Alien3::draw()
{
	for(int i = 0; i < 62; i++){
	    glPushMatrix();
	    this->ctmMultiply();
		glScalef(s, s, s);
		cube[i]->draw();
		glPopMatrix();
	}

}

void Alien3::changeForm(){
	if (counter == 0){
		cube[60]->translate(0, -2, 0);
		cube[61]->translate(0, 2, 0);

		counter = 1;
	}

	else{
		cube[60]->translate(0, 2, 0);
		cube[61]->translate(0, -2, 0);

		counter = 0;
	}
}

