/*
 * Alien.cpp
 *
 *  Created on: 2021 Dec 1
 *      Author: Terry
 */
#include "Alien.hpp"
#include <stdio.h>


Alien::Alien()
{
	//Layer 1
	cube[0] =  new Cube();
	cube[0]->setParentMC(&mc);
	cube[0]->translate(0,-3, 8);

	cube[1] =  new Cube();
	cube[1]->setParentMC(&mc);
	cube[1]->translate(0, 3, 8);

	//Layer 2
	cube[2] =  new Cube();
	cube[2]->setParentMC(&mc);
	cube[2]->translate(0, -2, 7);

	cube[3] =  new Cube();
	cube[3]->setParentMC(&mc);
	cube[3]->translate(0, 2, 7);

	//Layer 3
	for (int i = 4; i < 11; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0, i-7, 6);
	}

	//Layer 4
	for (int i = 11; i < 13; i++){
			cube[i] =  new Cube();
			cube[i]->setParentMC(&mc);
			cube[i]->translate(0, i-15, 5);
	}
	for (int i = 13; i < 16; i++){
			cube[i] =  new Cube();
			cube[i]->setParentMC(&mc);
			cube[i]->translate(0, i-14, 5);
	}
	for (int i = 16; i < 18; i++){
			cube[i] =  new Cube();
			cube[i]->setParentMC(&mc);
			cube[i]->translate(0, i-13, 5);
	}
	//Layer 5
	for (int i = 18; i < 29; i++){
			cube[i] =  new Cube();
			cube[i]->setParentMC(&mc);
			cube[i]->translate(0, i-23, 4);
	}

	//Layer 6
	cube[29] =  new Cube();
	cube[29]->setParentMC(&mc);
	cube[29]->translate(0, -5, 3);

	for (int i = 30; i < 37; i++){
			cube[i] =  new Cube();
			cube[i]->setParentMC(&mc);
			cube[i]->translate(0, i-33, 3);
	}

	cube[37] =  new Cube();
	cube[37]->setParentMC(&mc);
	cube[37]->translate(0, 5, 3);

	//Layer 7
	cube[38] =  new Cube();
	cube[38]->setParentMC(&mc);
	cube[38]->translate(0, -5, 2);

	cube[39] =  new Cube();
	cube[39]->setParentMC(&mc);
	cube[39]->translate(0, -3, 2);

	cube[40] =  new Cube();
	cube[40]->setParentMC(&mc);
	cube[40]->translate(0, 3, 2);

	cube[41] =  new Cube();
	cube[41]->setParentMC(&mc);
	cube[41]->translate(0, 5, 2);

	//Layer 8
	cube[42] =  new Cube();
	cube[42]->setParentMC(&mc);
	cube[42]->translate(0, -2, 1);

	cube[43] =  new Cube();
	cube[43]->setParentMC(&mc);
	cube[43]->translate(0, -1, 1);

	cube[44] =  new Cube();
	cube[44]->setParentMC(&mc);
	cube[44]->translate(0, 1, 1);

	cube[45] =  new Cube();
	cube[45]->setParentMC(&mc);
	cube[45]->translate(0, 2, 1);

	for(int i = 0; i < 45; i++){
			cube[i]->setFaceColor(0, 1.0, 0);
		}

	counter = 0;
}

Alien::~Alien()
{
	for(int i = 0; i < 46; i++){
		delete cube[i];
	}

	counter = 0;

}



void Alien::draw()
{
	for(int i = 0; i < 46; i++){
	    glPushMatrix();
	    this->ctmMultiply();
		glScalef(s, s, s);
		cube[i]->draw();
		glPopMatrix();
	}

}

void Alien::changeForm(){
	if (counter == 0){
		cube[18]->translate(0, 0, 3);
		cube[28]->translate(0, 0, 3);
		cube[29]->translate(0, 0, 3);
		cube[37]->translate(0, 0, 3);
		cube[38]->translate(0, 0, 3);
		cube[41]->translate(0, 0, 3);
		cube[39]->translate(0, 1, 0);
		cube[40]->translate(0, -1, 0);
		cube[43]->translate(0, -2, -1);
		cube[44]->translate(0, 2, -1);
		counter = 1;
	}

	else{
		cube[18]->translate(0, 0, -3);
		cube[28]->translate(0, 0, -3);
		cube[29]->translate(0, 0, -3);
		cube[37]->translate(0, 0, -3);
		cube[38]->translate(0, 0, -3);
		cube[41]->translate(0, 0, -3);
		cube[39]->translate(0, -1, 0);
		cube[40]->translate(0, 1, 0);
		cube[43]->translate(0, 2, 1);
		cube[44]->translate(0, -2, 1);
		counter = 0;
	}
}

