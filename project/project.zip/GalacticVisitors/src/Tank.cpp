/*
 * Tank.cpp
 *
 *  Created on: 2021 Dec 1
 *      Author: Terry
 */

#include "Tank.hpp"
#include <stdio.h>

Tank::Tank()
{
	//Layer 1
	cube[0] =  new Cube();
	cube[0]->setParentMC(&mc);
	cube[0]->translate(0,0, 7);

	//Layer 2
	for (int i = 1; i < 4; i++){
	cube[i] =  new Cube();
	cube[i]->setParentMC(&mc);
	cube[i]->translate(0,-2+i, 6);
	}

	//Layer 3
	for (int i = 4; i < 7; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,-5+i, 5);
		}
	//Layer 4
	for (int i = 7; i < 16; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,-11+i, 4);
		}
	//Layer 5
	for (int i = 16; i < 27; i++){
			cube[i] =  new Cube();
			cube[i]->setParentMC(&mc);
			cube[i]->translate(0,-21+i, 3);
			}
	//Layer 6
	for (int i = 27; i < 38; i++){
			cube[i] =  new Cube();
			cube[i]->setParentMC(&mc);
			cube[i]->translate(0,-32+i, 2);
			}
	for (int i = 0; i < 38; i++){
			cube[i]->setFaceColor(0, 1, 1);
		}
}

Tank::~Tank()
{
	for(int i = 0; i < 38; i++){
		delete cube[i];
	}

}

void Tank::draw()
{
	for(int i = 0; i < 38; i++){
	    glPushMatrix();
	    this->ctmMultiply();
		glScalef(s, s, s);
		cube[i]->draw();
		glPopMatrix();
	}

}

void Tank::changeForm(){

}
