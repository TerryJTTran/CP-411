/*
 * Explosion.hpp
 *
 *  Created on: 2021 Dec 2
 *      Author: Terry
 */

#ifndef SRC_EXPLOSION_HPP_
#define SRC_EXPLOSION_HPP_


#include <GL/glut.h>

#include "Cube.hpp"


class Explosion: public Shape{
protected:
	Cube* cube[46];
public:
	~Explosion();
	Explosion();
	void draw();
	void changeForm();
};



#endif /* SRC_EXPLOSION_HPP_ */
