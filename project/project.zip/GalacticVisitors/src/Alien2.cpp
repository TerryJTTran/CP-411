/*
 * Alien2.cpp
 *
 *  Created on: 2021 Dec 7
 *      Author: Terry
 */


#include "Alien2.hpp"
#include <stdio.h>


Alien2::Alien2()
{
	//Layer 1
	for (int i = 0; i < 3; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-1, 8);
	}

	//Layer 2
	for (int i = 3; i < 8; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-5, 7);
	}

	//Layer 3
	for (int i = 8; i < 15; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-11, 6);
	}

	//Layer 4
	for (int i = 15; i < 17; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-19, 5);
	}

	for (int i = 17; i < 20; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-18, 5);
	}

	for (int i = 20; i < 22; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-17, 5);
	}

	//Layer 5
	for (int i = 22; i < 31; i++){
		cube[i] =  new Cube();
		cube[i]->setParentMC(&mc);
		cube[i]->translate(0,i-26, 4);
	}

	//Layer 6
		cube[31] =  new Cube();
		cube[31]->setParentMC(&mc);
		cube[31]->translate(0,-2, 3);

		cube[32] =  new Cube();
		cube[32]->setParentMC(&mc);
		cube[32]->translate(0,2, 3);

	//Layer 7
		cube[33] =  new Cube();
		cube[33]->setParentMC(&mc);
		cube[33]->translate(0,-3, 2);

		cube[34] =  new Cube();
		cube[34]->setParentMC(&mc);
		cube[34]->translate(0,-1, 2);

		cube[35] =  new Cube();
		cube[35]->setParentMC(&mc);
		cube[35]->translate(0,0, 2);

		cube[36] =  new Cube();
		cube[36]->setParentMC(&mc);
		cube[36]->translate(0,1, 2);

		cube[37] =  new Cube();
		cube[37]->setParentMC(&mc);
		cube[37]->translate(0,3, 2);

	//Layer 8
		cube[38] =  new Cube();
		cube[38]->setParentMC(&mc);
		cube[38]->translate(0,-4, 1);

		cube[39] =  new Cube();
		cube[39]->setParentMC(&mc);
		cube[39]->translate(0,-2, 1);

		cube[40] =  new Cube();
		cube[40]->setParentMC(&mc);
		cube[40]->translate(0,2, 1);

		cube[41] =  new Cube();
		cube[41]->setParentMC(&mc);
		cube[41]->translate(0,4, 1);

	for(int i = 0; i < 42; i++){
			cube[i]->setFaceColor(0, 1.0, 0.5);
		}

	counter = 0;
}

Alien2::~Alien2()
{
	for(int i = 0; i < 42; i++){
		delete cube[i];
	}

	counter = 0;

}



void Alien2::draw()
{
	for(int i = 0; i < 42; i++){
	    glPushMatrix();
	    this->ctmMultiply();
		glScalef(s, s, s);
		cube[i]->draw();
		glPopMatrix();
	}

}

void Alien2::changeForm(){
	if (counter == 0){
		cube[34]->translate(0, 0, 2);
		cube[35]->translate(0, 0, 2);
		cube[36]->translate(0, 0, 2);

		cube[38]->translate(0, 0, 3);
		cube[41]->translate(0, 0, 3);

		counter = 1;
	}

	else{
		cube[34]->translate(0, 0, -2);
		cube[35]->translate(0, 0, -2);
		cube[36]->translate(0, 0, -2);

		cube[38]->translate(0, 0, -3);
		cube[41]->translate(0, 0, -3);
		counter = 0;
	}
}

