/*
 * Alien3.hpp
 *
 *  Created on: 2021 Dec 7
 *      Author: Terry
 */

#ifndef SRC_ALIEN3_HPP_
#define SRC_ALIEN3_HPP_



#include <GL/glut.h>

#include "Cube.hpp"


class Alien3: public Shape{
protected:
	Cube* cube[62];
	int counter;
public:
	~Alien3();
	Alien3();
	void draw();
	void changeForm();
};



#endif /* SRC_ALIEN3_HPP_ */
