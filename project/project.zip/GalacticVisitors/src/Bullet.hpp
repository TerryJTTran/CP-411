/*
 * Bullet.hpp
 *
 *  Created on: 2021 Dec 2
 *      Author: Terry
 */

#ifndef SRC_BULLET_HPP_
#define SRC_BULLET_HPP_



#include <GL/glut.h>

#include "Cube.hpp"


class Bullet: public Shape{
protected:
	Cube* cube[4];
public:
	~Bullet();
	Bullet();
	void draw();
	void changeForm();
};


#endif /* SRC_BULLET_HPP_ */
