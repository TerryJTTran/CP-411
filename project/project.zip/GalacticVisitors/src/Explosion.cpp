/*
 * Explosion.cpp
 *
 *  Created on: 2021 Dec 2
 *      Author: Terry
 */


#include "Explosion.hpp"
#include <stdio.h>

Explosion::Explosion()
{
	//Layer 1
	cube[0] =  new Cube();
	cube[0]->setParentMC(&mc);
	cube[0]->translate(0,-2, 7);

	cube[1] =  new Cube();
	cube[1]->setParentMC(&mc);
	cube[1]->translate(0,2, 7);

	cube[2] =  new Cube();
	cube[2]->setParentMC(&mc);
	cube[2]->translate(0,-5, 6);

	cube[3] =  new Cube();
	cube[3]->setParentMC(&mc);
	cube[3]->translate(0,5, 6);

	//Layer 2
	cube[4] =  new Cube();
	cube[4]->setParentMC(&mc);
	cube[4]->translate(0,-1, 6);

	cube[5] =  new Cube();
	cube[5]->setParentMC(&mc);
	cube[5]->translate(0,1, 6);

	cube[6] =  new Cube();
	cube[6]->setParentMC(&mc);
	cube[6]->translate(0,-4, 5);

	cube[7] =  new Cube();
	cube[7]->setParentMC(&mc);
	cube[7]->translate(0,4, 5);


	//Layer 3
	cube[8] =  new Cube();
	cube[8]->setParentMC(&mc);
	cube[8]->translate(0,-3, 4);

	cube[9] =  new Cube();
	cube[9]->setParentMC(&mc);
	cube[9]->translate(0,3, 4);

	//Layer 4
	cube[10] =  new Cube();
	cube[10]->setParentMC(&mc);
	cube[10]->translate(0,-6, 3);

	cube[11] =  new Cube();
	cube[11]->setParentMC(&mc);
	cube[11]->translate(0, 6, 3);

	cube[12] =  new Cube();
	cube[12]->setParentMC(&mc);
	cube[12]->translate(0,-5, 3);

	cube[13] =  new Cube();
	cube[13]->setParentMC(&mc);
	cube[13]->translate(0, 5, 3);

	//Layer 5
	cube[14] =  new Cube();
	cube[14]->setParentMC(&mc);
	cube[14]->translate(0,-3, 2);

	cube[15] =  new Cube();
	cube[15]->setParentMC(&mc);
	cube[15]->translate(0,3, 2);

	//Layer 6
	cube[16] =  new Cube();
	cube[16]->setParentMC(&mc);
	cube[16]->translate(0,-1, 1);

	cube[17] =  new Cube();
	cube[17]->setParentMC(&mc);
	cube[17]->translate(0,1, 1);

	cube[18] =  new Cube();
	cube[18]->setParentMC(&mc);
	cube[18]->translate(0,-4, 1);

	cube[19] =  new Cube();
	cube[19]->setParentMC(&mc);
	cube[19]->translate(0,4, 1);

	//Layer 7
	cube[20] =  new Cube();
	cube[20]->setParentMC(&mc);
	cube[20]->translate(0,-2, 0);

	cube[21] =  new Cube();
	cube[21]->setParentMC(&mc);
	cube[21]->translate(0,2, 0);

	cube[22] =  new Cube();
	cube[22]->setParentMC(&mc);
	cube[22]->translate(0,-5, 0);

	cube[23] =  new Cube();
	cube[23]->setParentMC(&mc);
	cube[23]->translate(0,5, 0);

	for (int i = 0; i < 24; i++){
		cube[i]->setFaceColor(1, 0, 0);
	}
}

Explosion::~Explosion()
{
	for(int i = 0; i < 24; i++){
		delete cube[i];
	}

}

void Explosion::draw()
{
	for(int i = 0; i < 24; i++){
	    glPushMatrix();
	    this->ctmMultiply();
		glScalef(s, s, s);
		cube[i]->draw();
		glPopMatrix();
	}

}

void Explosion::changeForm(){

}
