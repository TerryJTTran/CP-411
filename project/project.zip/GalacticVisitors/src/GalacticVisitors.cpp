#include <windows.h>  // for playing sound
#include <mmsystem.h> //

#include <GL/glew.h>
#include "GL/glaux.h"


#include <GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "Animation.hpp"
#include "World.hpp"
#include "Camera.hpp"
#include "Light.hpp"



GLint winWidth = 600, winHeight = 600;
GLint isInMove = 0,
	  xbegin = 0,
	  csType = 1,    /* coordinate system type: 1 for MCS, 2 for WCS, 3 for VCS */
	  transType = 4;  /* depends on csType  */

CullMode cullMode = BACKFACE;      /* culling option */
RenderMode renderMode =  CONSTANT;//TEXTURE;  /* shade option  */

World myWorld;
Camera myCamera;
Light myLight;
Shape *selectObj = NULL;  // pointer to select object
GLint displayOption = 0;   /* 0: world, 1: solar system, 2: control points, 3: curve, 4: rotation surface.  */

GLuint ProgramObject;  /* GLSL program object */



void init(void) {

}


void display(void) {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	switch (displayOption) {
	case 0:
	   myCamera.setProjectionMatrix();
	   myWorld.draw();
	   myLight.draw();
	 break;
	}
	glFlush();
	glutSwapBuffers();
}


void winReshapeFcn(GLint newWidth, GLint newHeight) {
	glViewport(0, 0, newWidth, newHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	winWidth = newWidth;
	winHeight = newHeight;
}

void NormalKeysFcn(unsigned char key, int x, int y){

	if(key == 32){
		tankAction(0);
	}
	else if(key == 'q') {
		exit(0);
	}
	else if(key == 's') {
		glutIdleFunc(gameStart);
	}

}

void SpecialKeysFcn(int key, int x, int y){

	switch (key){

		case GLUT_KEY_LEFT : tankAction(-1); break;

		case GLUT_KEY_RIGHT : tankAction(1); break;

	}

}


int main(int argc, char** argv) {
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(winWidth, winHeight);
	glutCreateWindow("GalacticVisitors");

	glewInit(); // this is for GSLS


	init();

	glutIdleFunc(NULL);
	glutDisplayFunc(display);
	glutKeyboardFunc(NormalKeysFcn);
	glutSpecialFunc(SpecialKeysFcn);
	glutMainLoop();
	return 0;
}
