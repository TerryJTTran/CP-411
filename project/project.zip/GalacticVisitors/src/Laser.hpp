/*
 * Laser.hpp
 *
 *  Created on: 2021 Dec 7
 *      Author: Terry
 */

#ifndef SRC_LASER_HPP_
#define SRC_LASER_HPP_



#include <GL/glut.h>

#include "Cube.hpp"


class Laser: public Shape{
protected:
	Cube* cube[7];
	int counter;
public:
	~Laser();
	Laser();
	void draw();
	void changeForm();
};


#endif /* SRC_LASER_HPP_ */
