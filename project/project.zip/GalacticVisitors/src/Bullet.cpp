/*
 * Bullet.cpp
 *
 *  Created on: 2021 Dec 2
 *      Author: Terry
 */


#include "Bullet.hpp"
#include <stdio.h>

Bullet::Bullet()
{
	//Layer 1
	cube[0] =  new Cube();
	cube[0]->setParentMC(&mc);
	cube[0]->translate(0,0, 7);


	//Layer 2
	cube[1] =  new Cube();
	cube[1]->setParentMC(&mc);
	cube[1]->translate(0,0, 6);

	//Layer 3
	cube[2] =  new Cube();
	cube[2]->setParentMC(&mc);
	cube[2]->translate(0,0, 5);

	//Layer 4
	cube[3] =  new Cube();
	cube[3]->setParentMC(&mc);
	cube[3]->translate(0,0, 4);
	for (int i = 0; i < 4; i++){
			cube[i]->setFaceColor(1, 1, 1);
		}
}

Bullet::~Bullet()
{
	for(int i = 0; i < 4; i++){
		delete cube[i];
	}

}

void Bullet::draw()
{
	for(int i = 0; i < 4; i++){
	    glPushMatrix();
	    this->ctmMultiply();
		glScalef(s, s, s);
		cube[i]->draw();
		glPopMatrix();
	}

}

void Bullet::changeForm(){

}
