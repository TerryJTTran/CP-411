/*
 * Alien2.hpp
 *
 *  Created on: 2021 Dec 7
 *      Author: Terry
 */

#ifndef SRC_ALIEN2_HPP_
#define SRC_ALIEN2_HPP_


#include <GL/glut.h>

#include "Cube.hpp"


class Alien2: public Shape{
protected:
	Cube* cube[42];
	int counter;
public:
	~Alien2();
	Alien2();
	void draw();
	void changeForm();
};

#endif /* SRC_ALIEN2_HPP_ */
