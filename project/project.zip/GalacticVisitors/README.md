Galactic Visitors
By: Terry Tran


Controls
Left Arrow Key: Move left
Right Arrow Key: Move right
Space Key: Shoot
Q Key: Quit game
S Key: Start game

How to play
Try to shoot all the aliens before they reach you or shoot you.
