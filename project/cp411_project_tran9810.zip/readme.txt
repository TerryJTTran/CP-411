Title: GalacticVisitors 
Name: Terry Tran
ID: 190199810
Email: tran9810@mylaurier.ca
Team: individual
WorkID: cp411-project
Statement: I claim that the enclosed project submission is my individual work, or I made significant contribution to the project.  

Fill in the self-evaluation in the following evaluation grid.
Symbols: R -- Project requirements
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Evaluation grid: [self-evaluation/total/marker-evaluation]

Project

R1 Proposal

R1.1 Application and problem description  [5/5/*]
R1.2 Creativity or rationals              [5/5/*]
R1.3 Design consideration                 [5/5/*]
R1.4 Milestones and schedule              [5/5/*]
R1.5 References                           [5/5/*]
R1.6 Writing of the proposal              [5/5/*]

R2 Design & implementation

R2.1 Problem solving and algorithms       [30/30/*]
R2.2 Completion of the project            [30/30/*]
R2.3 New features                         [20/20/*]
R2.4 Program design and organization      [20/20/*]

R3 Project presentation

R3.1 Project documentation                [10/10/*]
R3.2 Project demonstration                [10/10/*]

Total:                                    [150/150/*]
