/*
 * Description: SimpleView reference design
 * Author: HBF
 * Version: 2021-10-06
 */
#ifndef HHOUSE_H
#define HHOUSE_H

#include <GL/glut.h>
#include "Shape.hpp"
#include "Vector.hpp"

class House: public Shape {
protected:
	//GLfloat vertex[9][3];  /* 2D array to store house vertices */
	//GLint face[9][4];      /* 2D array to store faces */
	GLfloat r, g, b;       /* color house */
public:
	Shape *cube;
	Shape *pyramid;
	House();
	void draw();
	void drawFace(int);
};

#endif
