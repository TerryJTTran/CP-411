/*
 * Test TinyXML for SVG
 * HBF
 */

#include <stdio.h>
#include "tinyxml.h"

int main() {
	{
		// Load svg from form SVG string, save to svg file
		char *svgstr =
				"<?xml version=\"1.0\" standalone=\"no\"?>"
						"<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">"
						"<svg width=\"640\" height=\"480\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\">\n"
						"<rect x=\"100\" y=\"150\" width=\"50\" height=\"59\" stroke=\"red\" stroke-width=\"3\" fill=rgb(255,0,0)/>"
						"</svg>";

		/*
		 * Can also use style to specify drawing object, e.g
		 * "<rect x=\"217\" y=\"149\" width=\"63\" height=\"69\" style=\"fill:rgb(255,0,0);stroke-width:1;stroke:rgb(255,0,0)\"/>"
		 */
		TiXmlDocument doc("");
		doc.Parse(svgstr);
		if (doc.Error()) {
			printf("Error in %s: %s\n", doc.Value(), doc.ErrorDesc());
			exit(1);
		}

		printf("** Printing via doc.Print **\n");
		doc.Print(stdout);

		printf("** Printing via TiXmlPrinter **\n");
		TiXmlPrinter printer;
		doc.Accept(&printer);
		fprintf( stdout, "%s", printer.CStr());

		doc.SaveFile("output.svg");
	}

	{  // load svg from file, modify and save it to another svg file
		TiXmlDocument doc("output.svg");
		bool loadOkay = doc.LoadFile();

		if (!loadOkay) {
			printf("Error='%s'.\n", doc.ErrorDesc());
			exit(1);
		}

		printf("** Print SVG after loading from file  **\n");
		doc.Print(stdout);

		TiXmlNode* node = doc.FirstChild("svg");
		assert(node);
		TiXmlElement* svgElement = node->ToElement();

		svgElement->SetAttribute("width", "400");
		svgElement->SetAttribute("height", "400");

		doc.Print( stdout);

		TiXmlElement* objectElement = svgElement->FirstChildElement("rect");
		fprintf( stdout, "objectElement.Value():%s\n", objectElement->Value());
		fprintf( stdout, "objectElement->Attribute(\"x\"):%s\n",
				objectElement->Attribute("x"));
		objectElement->SetAttribute("x", 300);
		fprintf( stdout, "After set, objectElement->Attribute(\"x\"):%s\n",
				objectElement->Attribute("x"));
		objectElement->SetAttribute("width", 100);
		objectElement->SetAttribute("height", 100);
		objectElement->SetAttribute("fill", "blue");

		TiXmlElement circle("circle");
		circle.SetAttribute("cx", 50);
		circle.SetAttribute("cy", 50);
		circle.SetAttribute("r", 40);
		circle.SetAttribute("stroke", "black");
		circle.SetAttribute("stroke-width", "3");
		circle.SetAttribute("fill", "red");
		fprintf( stdout, "circle.Value():%s\n", circle.Value());
		svgElement->InsertEndChild(circle);
		doc.Print( stdout);
		doc.SaveFile("output1.svg");
	}

	return 0;
}
