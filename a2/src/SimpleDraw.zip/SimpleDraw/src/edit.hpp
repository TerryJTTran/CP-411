/*
 * edit.hpp
 *
 *  Created on: 2021 Oct 4
 *      Author: Terry
 */

#ifndef EDIT_HPP_
#define EDIT_HPP_


#include <GL/glut.h>





#endif /* EDIT_HPP_ */
