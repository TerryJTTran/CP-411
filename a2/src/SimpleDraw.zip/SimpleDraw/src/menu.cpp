/*
 * menu.cpp
 *
 *  Created on: 2021 Oct 4
 *      Author: Terry
 */
#include "menu.hpp"
#include "object.hpp"
#include "file.hpp"
#include <GL/glut.h>

extern int objExists;
extern int userMode;							  	// Identifier for if user is in drawing or edit mode.
extern int drawingOption;
extern int window;									  	// Window identifier.
extern int interval;							  	// Click stage interval.
extern int strokeWidthValue;					  	// Stroke width value.
extern int drawMode;							  	// Initial draw shape (circle).
extern GLsizei winWidth, winHeight;      	// Initial Display-window size.
extern int outlineColor;
extern int fillColor;

extern GLenum renderingMode;             	// Initial fill method.
extern GLubyte *bits;             				// pointers to image data (array of bytes)
extern BITMAPINFOHEADER *bih;     				// point to bitmap information header object



extern point mouseMovement[2];					// Holds the starting and stoping position of mouse coordinates while holding left click.
extern int objectCount;
extern int moveMode;

extern node *startObj;							// Holds front object.
extern node *endObj;							// Holds back object.
extern node *currentObj;						// Holds node of currently selected object.



//* menu design
void mainMenu(GLint renderingOption)
{
   switch(renderingOption) {
	   case 1:  clean(&startObj,&endObj); objectCount=0; break;
	   case 2:  glutDestroyWindow(window);  break;
   }
}

/*  Set fill color values according to the submenu option selected.  */
void fillColorSubMenu(GLint colorOption)
{
   switch(colorOption) {
   	   //blue
	   case 1:
		   fillColor = 0;
		   break;
	   //green
	   case 2:
		   fillColor = 1;
		   break;
	   //red
	   case 3:
		   fillColor = 2;
		   break;
	   //black
	   case 4:
		   fillColor = 3;
		   break;
	   //white
	   case 5:
		   fillColor = 4;
		   break;
	   //purple
	   case 6:
		   fillColor = 5;
		   break;
	   //cyan
	   case 7:
		   fillColor = 6;
		   break;
	   //yellow
	   case 8:
		   fillColor = 7;
		   break;
   }
   glutPostRedisplay( );
}

/*  Set outline color values according to the submenu option selected.  */
void outlineColorSubMenu(GLint colorOption)
{
   switch(colorOption) {
   	   //blue
	   case 1:
		   outlineColor = 0;
		   break;
	   //green
	   case 2:
		   outlineColor = 1;
		   break;
	   //red
	   case 3:
		   outlineColor = 2;
		   break;
	   //black
	   case 4:
		   outlineColor = 3;
		   break;
	   //white
	   case 5:
		   outlineColor = 4;
		   break;
	   //purple
	   case 6:
		   outlineColor = 5;
		   break;
	   //cyan
	   case 7:
		   outlineColor = 6;
		   break;
	   //yellow
	   case 8:
		   outlineColor = 7;
		   break;
   }
   glutPostRedisplay( );
}

/*  Set shape value according to the submenu option selected.  */
void drawSubMenu(GLint shapeOption)
{
   switch(shapeOption) {
	   case 1:
		   drawMode = 0;
		   break;
	   case 2:
		   drawMode = 1;
		   break;
   }
   glutPostRedisplay( );
}

/*  Set width value according to the submenu option selected.  */
void widthSubMenu(GLint widthOption)
{
   switch(widthOption) {
	   case 1:
		   strokeWidthValue = 1.0;
		   break;
	   case 2:
		   strokeWidthValue = 2.0;
		   break;
	   case 3:
		   strokeWidthValue = 3.0;
		   break;
	   case 4:
		   strokeWidthValue = 4.0;
		   break;
	   case 5:
		   strokeWidthValue = 5.0;
		   break;
   }
}

/* Edit*/
void editMenu(GLint editOption){
	switch(editOption){
	case 1:							// Select
		userMode = 1;				// Set user to edit mode.
		break;
	case 2:							// Delete
		if(userMode == 1 && interval == 1){
		deleteNode(&startObj, &endObj, objExists);
		objectCount -= 1;
		userMode = 0;
		interval = 0;
		}
		break;
	case 3:							// Move front
		if(userMode == 1 && interval == 1){
			moveNodeFront(&startObj, &endObj, currentObj,objExists);
			userMode = 0;
			interval = 0;
		}
		break;
	case 4:							// Move back
		if(userMode == 1 && interval == 1){
			moveNodeBack(&startObj, &endObj, currentObj,objExists);
			userMode = 0;
			interval = 0;
		}
		break;
	case 5:							// Move around
		moveMode = 1;
		interval = 2;
		break;
	}
}

/* File*/
void fileMenu(GLint fileOption){
	switch(fileOption){
	case 1:							// Save SVG
		svgSave(&startObj,&endObj,objectCount);
		break;
	case 2:							// Open SVG
		objectCount = 0;
		clean(&startObj,&endObj);
		objectCount = svgOpen(&startObj,&endObj,objectCount);
		break;
	case 3:							// Export Bitmap
	    saveBitmap("output.bmp", 0, 0, winWidth, winHeight);
		break;
	}
}

void addMenu(){
	GLint ocSubMenu;             // Identifier for outline color submenu.
		GLint fcSubMenu;             // Identifier for fill color submenu.
		GLint dSubMenu;				// Identifier for shape submenu.
		GLint wSubMenu;				// Identifier for width size submenu.
		GLint stSubMenu;				// Identifier for style submenu.
		GLint eSubMenu;				// Identifier for edit submenu.
		GLint fSubMenu;				// Identifier for file submenu.

		// Create outline color submenu
			ocSubMenu = glutCreateMenu(outlineColorSubMenu);
			   glutAddMenuEntry("Blue", 1);
			   glutAddMenuEntry("Green", 2);
			   glutAddMenuEntry("Red", 3);
			   glutAddMenuEntry("Black", 4);
			   glutAddMenuEntry("White", 5);
			   glutAddMenuEntry("Purple", 6);
			   glutAddMenuEntry("Cyan", 7);
			   glutAddMenuEntry("Yellow", 8);

		// Create fill color submenu
			 fcSubMenu = glutCreateMenu(fillColorSubMenu);
			   glutAddMenuEntry("Blue", 1);
			   glutAddMenuEntry("Green", 2);
			   glutAddMenuEntry("Red", 3);
			   glutAddMenuEntry("Black", 4);
			   glutAddMenuEntry("White", 5);
			   glutAddMenuEntry("Purple", 6);
			   glutAddMenuEntry("Cyan", 7);
			   glutAddMenuEntry("Yellow", 8);


		// Create shape submenu
			dSubMenu = glutCreateMenu(drawSubMenu);
				glutAddMenuEntry("Circle", 1);
				glutAddMenuEntry("Rectangle", 2);

		// Create width submenu
			wSubMenu = glutCreateMenu(widthSubMenu);
				glutAddMenuEntry("1.0", 1);
				glutAddMenuEntry("2.0", 2);
				glutAddMenuEntry("3.0", 3);
				glutAddMenuEntry("4.0", 4);
				glutAddMenuEntry("5.0", 5);

		// Create style submenu
			stSubMenu = glutCreateMenu(mainMenu);
			   glutAddSubMenu("Fill Color", fcSubMenu);
			   glutAddSubMenu("Stroke Color", ocSubMenu);
			   glutAddSubMenu("Stroke Width", wSubMenu);

		// Create edit submenu
			eSubMenu = glutCreateMenu(editMenu);
				glutAddMenuEntry("Select", 1);
				glutAddMenuEntry("Delete", 2);
				glutAddMenuEntry("Move Front", 3);
				glutAddMenuEntry("Move Back", 4);
				glutAddMenuEntry("Move Around", 5);

		// Create file submenu
			fSubMenu = glutCreateMenu(fileMenu);
			glutAddMenuEntry("Save SVG", 1);
			glutAddMenuEntry("Open SVG", 2);
			glutAddMenuEntry("Export Bitmap", 3);

		// Create main pop-up menu.
			   glutCreateMenu(mainMenu);
			   glutAddMenuEntry("New", 1);
			   glutAddSubMenu("Draw", dSubMenu);
			   glutAddSubMenu("Style", stSubMenu);
			   glutAddSubMenu("Edit", eSubMenu);
			   glutAddSubMenu("File", fSubMenu);
			   glutAddMenuEntry("Quit", 2);

			   /* Select menu option using right mouse button.  */
			   glutAttachMenu(GLUT_RIGHT_BUTTON);
}
