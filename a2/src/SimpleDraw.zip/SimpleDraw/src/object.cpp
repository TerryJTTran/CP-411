/*
 * object.cpp
 *
 *  Created on: 2021 Oct 4
 *      Author: Terry
 */


#include "object.hpp"


node* newNode(point list[2], int shape,int outColor, int filColor, int strokeWidth){
	node *ptr = (node*) malloc(sizeof(node));
	ptr->list[0].x = list[0].x;
	ptr->list[1].x = list[1].x;
	ptr->list[0].y = list[0].y;
	ptr->list[1].y = list[1].y;
	ptr->shape = shape;
	ptr->strokeWidth = strokeWidth;
	ptr->outColor = outColor;
	ptr->filColor = filColor;
	ptr->next = NULL;
	ptr->prev = NULL;
	return ptr;
}

void moveNodeBack(node **startNode, node **endNode, node *curNode, int nodePosition){
	if(*startNode == NULL){					// No objects in node list.
		*startNode = curNode;
		*endNode = curNode;
	}
	else if(nodePosition == 0){				// Add new node from back.
			curNode->next = NULL;
			(*endNode)->next = curNode;
			curNode->prev = *endNode;
			*endNode = curNode;
		}

	else if(*startNode != *endNode){		// Move existing node to back.
	node *tempObj = (node*) malloc(sizeof(node));
	node *prevObj = (node*) malloc(sizeof(node));
	tempObj = *startNode;
	prevObj = NULL;
	for (int i = 1; i <= nodePosition;i++){

		if(i == nodePosition){

			if(tempObj->prev == NULL){								// If front of list.
				*startNode = (*startNode)->next;
				(*startNode)->prev = NULL;
				tempObj->prev = *endNode;
				(*endNode)->next = tempObj;
				tempObj->next = NULL;
				*endNode = tempObj;
			}

			else if(tempObj->next == NULL){							// If back of list.
			}

			else{													// In middle of list.
				prevObj->next = tempObj->next;
				tempObj->next->prev = prevObj;
				(*endNode)->next = tempObj;
				tempObj->prev = *endNode;
				*endNode = tempObj;
				tempObj->next = NULL;
			}
			return;
		}

		else{
			prevObj = tempObj;
			tempObj = tempObj->next;
		}
	}
	}
}

void moveNodeFront(node **startNode, node **endNode, node *curNode, int nodePosition){
	if(*startNode == NULL){											// No objects in node list.
		*startNode = curNode;
		*endNode = curNode;
	}
	else if(nodePosition == 0){										// Add new node from front.
		curNode->prev = NULL;
		(*startNode)->prev = curNode;
		curNode->next = *startNode;
		*startNode = curNode;
	}
	else if(*startNode != *endNode){
		node *tempObj = (node*) malloc(sizeof(node));
		node *prevObj = (node*) malloc(sizeof(node));
		tempObj = *startNode;
		prevObj = NULL;
		for (int i = 1; i <= nodePosition;i++){

			if(i == nodePosition){

				if(tempObj->prev == NULL){								// If front of list.
				}

				else if(tempObj->next == NULL){							// If back of list.
					*endNode = (*endNode)->prev;
					(*endNode)->next = NULL;
					tempObj->next = *startNode;
					(*startNode)->prev = tempObj;
					tempObj->prev = NULL;
					*startNode = tempObj;
				}

				else{													// In middle of list.
					prevObj->next = tempObj->next;
					tempObj->next->prev = prevObj;
					(*startNode)->prev = tempObj;
					tempObj->next = *startNode;
					*startNode = tempObj;
					tempObj->prev = NULL;
				}
				return;
			}

			else{
				prevObj = tempObj;
				tempObj = tempObj->next;
			}
		}

	}
}

void deleteNode(node **startNode, node **endNode, int nodePosition){
	if (*startNode != NULL && *startNode == *endNode) { //One node in list
			*startNode = NULL;
			*endNode = NULL;
		}
	else{
		node *tempObj = (node*) malloc(sizeof(node));
		node *prevObj = (node*) malloc(sizeof(node));
		tempObj = *startNode;
		prevObj = NULL;
		for (int i = 1; i <= nodePosition;i++){

			if(i == nodePosition){

				if(tempObj->prev == NULL){								// If front of list.
					*startNode = (*startNode)->next;
					(*startNode)->prev = NULL;
					free(tempObj);
				}

				else if(tempObj->next == NULL){							// If back of list.
					*endNode = (*endNode)->prev;
					(*endNode)->next = NULL;
					free(tempObj);
				}

				else{													// In middle of list.
					prevObj->next = tempObj->next;
					tempObj->next->prev = prevObj;
					free(tempObj);
				}
				return;
			}

			else{
				prevObj = tempObj;
				tempObj = tempObj->next;
			}
		}
	}
	/*	else if (newNode != NULL){ //Not empty list
			if(newNode == *startNode){		// Front object was deleted.
				*startNode = newNode->next;
				(*startNode)->prev = NULL;
				*startNode = NULL;
				*endNode = NULL;
			}
			else if(newNode == *endNode){		// End object was deleted.
				*endNode = newNode->prev;
				(*endNode)->next = NULL;
				*startNode = NULL;
				*endNode = NULL;
			}
			else if(newNode->next != NULL && newNode->prev != NULL){
				newNode->next->prev = newNode->prev;
				newNode->prev->next = newNode->next;
			}
		}*/
}

int selectNode(node **startNode, node **endNode, node *newNode, point mousePosition[2]){

	newNode = *startNode;					// Set current node to front object.
	int objectOrder = 1;
	//Search through stored objects.
	while(newNode != NULL){
		if(newNode->shape == 0){					// If shape is circle.
			float currentRadius = sqrt(pow((newNode->list[0].y-newNode->list[1].y),2)+pow((newNode->list[0].x - newNode->list[1].x),2));
			float selectedRadius = sqrt(pow((newNode->list[0].y-mousePosition[0].y),2)+pow((newNode->list[0].x - mousePosition[0].x),2));
			if(selectedRadius <= currentRadius){	// Selected spot matches the next most front known object circle.
				return objectOrder;
			}
			else{									// Selected spot does not match the next most front known object circle.
				newNode = newNode->next;		// Set selected node to next known object.
			}
		}

		else{										// If shape is rectangle
			if(((newNode->list[1].x <= mousePosition[0].x && mousePosition[0].x <= newNode->list[0].x)
					|| (newNode->list[0].x <= mousePosition[0].x && mousePosition[0].x <= newNode->list[1].x))
					&& ((newNode->list[1].y <= mousePosition[0].y && mousePosition[0].y <= newNode->list[0].y)
							|| (newNode->list[0].y <= mousePosition[0].y && mousePosition[0].y <= newNode->list[1].y))){
													// Selected spot is within rectangle borders.
				return objectOrder;
			}
			else{									// Selected spot is not within rectangle borders.
				newNode = newNode->next;		// Set selected node to next known object.
			}

		}
		objectOrder += 1;
	}
	return objectOrder;
}

void moveNodeAround(node **startNode,node **endNode, int xMove, int yMove, int nodePosition){
		node *tempObj = (node*) malloc(sizeof(node));
	tempObj = *startNode;
	for (int i = 1; i <= nodePosition;i++){

		if(i == nodePosition){
			if(tempObj->shape == 1){


			tempObj->list[0].x -= xMove;
			tempObj->list[1].x -= xMove;
			tempObj->list[0].y -= yMove;
			tempObj->list[1].y -= yMove;
			}
			else{
				int xDiff = tempObj->list[0].x - tempObj->list[1].x;
				int yDiff = tempObj->list[0].y - tempObj->list[1].y;
				tempObj->list[0].x -= xMove;
				tempObj->list[0].y -= yMove;
				tempObj->list[1].x = tempObj->list[0].x + xDiff;
				tempObj->list[1].y = tempObj->list[0].y + yDiff;

			}
			return;
		}

		else{
			tempObj = tempObj->next;
		}
	}

}

void outlineNode(node **startNode,node **endNode, point list[2], int nodePosition){
	node *tempObj = (node*) malloc(sizeof(node));
tempObj = *startNode;
for (int i = 1; i <= nodePosition;i++){

	if(i == nodePosition){
		tempObj->list[1].x = list[1].x;
		tempObj->list[1].y = list[1].y;

		return;
	}

	else{
		tempObj = tempObj->next;
	}
}
}

void clean(node **startNode, node **endNode){
	node *currentNode = (node*) malloc(sizeof(node));
	while(*startNode != NULL){
		currentNode = *startNode;
		*startNode = (*startNode)->next;
		free(currentNode);
	}
	*startNode = NULL;
	*endNode = NULL;
}
