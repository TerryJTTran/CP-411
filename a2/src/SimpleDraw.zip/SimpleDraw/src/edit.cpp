/*
 * edit.cpp
 *
 *  Created on: 2021 Oct 4
 *      Author: Terry
 */

#include "object.hpp"
#include <GL/glut.h>


const float DEG2RAD = 3.14159/180;			  	// Pi degrees to radians.
GLfloat red[8] = {0.0,0.0,1.0,0.0,1.0,1.0,0.0,1.0}, green[8] = {0.0,1.0,0.0,0.0,1.0,0.0,1.0,1.0}, blue[8] = {1.0,0.0,0.0,0.0,1.0,1.0,1.0,0.0};  // Initial fill color values.

 void drawRectOut(point mouseCoords[2],int outColor, int strokeWidth, int fillColor)
{
  glColor3f(red[outColor], green[outColor], blue[outColor]);		 // Outline color.
  glPointSize(strokeWidth);                	// Shape Thickness
  glLineWidth(strokeWidth);				  	// Stroke Width.
  glBegin(GL_LINE_LOOP);
  glVertex2i(mouseCoords[0].x, mouseCoords[0].y);
  glVertex2i(mouseCoords[1].x, mouseCoords[0].y);
  glVertex2i(mouseCoords[1].x, mouseCoords[1].y);
  glVertex2i(mouseCoords[0].x, mouseCoords[1].y);
  glEnd( );
  glColor3f(red[fillColor], green[fillColor], blue[fillColor]);
}

void drawRectFil(point mouseCoords[2],int filColor, int strokeWidth, int fillColor)
{
  glColor3f(red[filColor], green[filColor], blue[filColor]);		 // Fill color.
  glPointSize(strokeWidth);                	// Shape Thickness
  glLineWidth(strokeWidth);				  	// Stroke Width.
  glBegin(GL_POLYGON);
  glVertex2i(mouseCoords[0].x, mouseCoords[0].y);
  glVertex2i(mouseCoords[1].x, mouseCoords[0].y);
  glVertex2i(mouseCoords[1].x, mouseCoords[1].y);
  glVertex2i(mouseCoords[0].x, mouseCoords[1].y);
  glEnd( );
  glColor3f(red[fillColor], green[fillColor], blue[fillColor]);
}

void drawCircleOut(point mouseCoords[2],int outColor, int strokeWidth, int fillColor){
	float x = mouseCoords[0].x;
	float y = mouseCoords[0].y;
	float radius = sqrt(pow((mouseCoords[0].y - mouseCoords[1].y),2)+pow((mouseCoords[0].x - mouseCoords[1].x),2));
	glColor3f(red[outColor], green[outColor], blue[outColor]);		 // Outline color.
	glPointSize(strokeWidth);                	// Shape Thickness
	glLineWidth(strokeWidth);				  	// Stroke Width.
	glBegin(GL_LINE_LOOP);
		for (int i=0;i<360;i++){
			float degInRad = i*DEG2RAD;
			glVertex2f(x+cos(degInRad)*radius,y+sin(degInRad)*radius);
		}
	glEnd();
	glColor3f(red[fillColor], green[fillColor], blue[fillColor]);
}

void drawCircleFil(point mouseCoords[2],int filColor, int strokeWidth, int fillColor){
	float x = mouseCoords[0].x;
	float y = mouseCoords[0].y;
	float radius = sqrt(pow((mouseCoords[0].y - mouseCoords[1].y),2)+pow((mouseCoords[0].x - mouseCoords[1].x),2));
	glColor3f(red[filColor], green[filColor], blue[filColor]);		 // Fill color.
	glPointSize(strokeWidth);                	// Shape Thickness
	glLineWidth(strokeWidth);				  	// Stroke Width.
	glBegin(GL_POLYGON);
	for (int i=0;i<360;i++){
		float degInRad = i*DEG2RAD;
		glVertex2f(x+cos(degInRad)*radius,y+sin(degInRad)*radius);
	}
	glEnd();
	glColor3f(red[fillColor], green[fillColor], blue[fillColor]);
}
