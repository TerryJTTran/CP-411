/*
 * file.hpp
 *
 *  Created on: 2021 Oct 4
 *      Author: Terry
 */

#ifndef FILE_HPP_
#define FILE_HPP_


#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include "math.h"

#endif /* FILE_HPP_ */

int saveBitmap(const char *ptrcFileName, int nX, int nY, int nWidth, int nHeight);


