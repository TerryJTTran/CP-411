/*
 * object.hpp
 *
 *  Created on: 2021 Oct 4
 *      Author: Terry
 */

#ifndef OBJECT_HPP_
#define OBJECT_HPP_
#endif /* OBJECT_HPP_ */


#include <GL/glut.h>
#include <stdio.h>
#include <math.h>



typedef struct dot {
	int x, y;
} point;

typedef struct node {
	point list[2];
	int shape;
	int outColor;
	int filColor;
	int strokeWidth;
	struct node *prev;
	struct node *next;
} node;


node* newNode(point list[2], int shape, int outColor, int filColor, int strokeWidth);
void moveNodeBack(node **startNode, node **endNode, node *curNode, int nodePosition);
void moveNodeFront(node **startNode, node **endNode, node *curNode, int nodePosition);
void deleteNode(node **startNode, node **endNode, int nodePosition);
int selectNode(node **startNode, node **endNode, node *newNode,point List[2]);
void moveNodeAround(node **startNode, node **endNode, int xMove, int yMove, int nodePosition);
void clean(node **startNode, node **endNode);
void outlineNode(node **startNode, node **endNode, point list[2], int nodePosition);


void drawRectOut(point mouseCoords[2],int outColor, int strokeWidth,int fillColor);
void drawRectFil(point mouseCoords[2],int outColor, int strokeWidth,int fillColor);
void drawCircleOut(point mouseCoords[2],int outColor, int strokeWidth,int fillColor);
void drawCircleFil(point mouseCoords[2],int outColor, int strokeWidth,int fillColor);
void drawBoard(node **startObj,node **endObj);



void svgSave(node **startNode, node **endNode, int objectCount);
int svgOpen(node **startNode, node **endNode, int objectCount);
