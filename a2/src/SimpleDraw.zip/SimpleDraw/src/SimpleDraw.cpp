/*
 * SimpleDraw.cpp
 *
 *  Created on: 2021 Oct 4
 *      Author: Terry
 */


#include <GL/glut.h>
#include <stdio.h>
#include <math.h>

#include "edit.hpp"
#include "menu.hpp"
#include "object.hpp"
#include "file.hpp"




int objExists = 0;
int userMode = 0;							  	// Identifier for if user is in drawing or edit mode.
int drawingOption = 0;
int window;									  	// Window identifier.
int interval = 0;							  	// Click stage interval.
int strokeWidthValue = 1.0;					  	// Stroke width value.
int drawMode = 1;							  	// Initial draw shape (circle).
GLsizei winWidth = 800, winHeight = 600;      	// Initial Display-window size.
int outlineColor = 2;
int fillColor = 2;

GLenum renderingMode = GL_SMOOTH;             	// Initial fill method.
GLubyte *bits = NULL;             				// pointers to image data (array of bytes)
BITMAPINFOHEADER *bih = NULL;     				// point to bitmap information header object



point mouseMovement[2];					// Holds the starting and stoping position of mouse coordinates while holding left click.
int objectCount = 0;
int moveMode = 0;

node *startObj = NULL;							// Holds front object.
node *endObj = NULL;							// Holds back object.
node *currentObj = newNode(mouseMovement,drawMode, outlineColor, fillColor, strokeWidthValue);						// Holds node of currently selected object.


void drawBoard(node **startObj,node **endObj);

void init(void) {
	glClearColor(1.0, 1.0, 1.0, 0.0); 					// Set display-window background color to white
	glMatrixMode(GL_PROJECTION);       					// Set projection parameters
	gluOrtho2D(0.0, 200.0, 0.0, 150.0); 				// Set view port, look down
}

void display(void) {
		glClear(GL_COLOR_BUFFER_BIT);
		drawBoard(&startObj,&endObj);
		//glColor3f(red[fillColor], green[fillColor], blue[fillColor]);		 			// Shape color.
		glPointSize(strokeWidthValue);                	// Shape Thickness
		glLineWidth(strokeWidthValue);				  	// Stroke Width.
		glFlush();     									// Process all OpenGL routines as quickly as possible.
}




void drawBoard(node **startObj,node **endObj){
	node *tempObj = *endObj;
	while(tempObj != NULL){										// Draw all stored objects.
		if(tempObj->shape == 0){
			drawCircleFil(tempObj->list, tempObj->filColor, tempObj->strokeWidth,fillColor);
			drawCircleOut(tempObj->list, tempObj->outColor, tempObj->strokeWidth,fillColor);
		}
		else{
			drawRectFil(tempObj->list, tempObj->filColor, tempObj->strokeWidth,fillColor);
			drawRectOut(tempObj->list, tempObj->outColor, tempObj->strokeWidth,fillColor);
		}
		tempObj = tempObj->prev;

	}
}


void winReshapeFcn(GLint newWidth, GLint newHeight)
{
  /*  Reset viewport and projection parameters  */
  glViewport(0, 0, newWidth, newHeight);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity( );
  gluOrtho2D(0.0, newWidth, 0.0, newHeight);

  /*  Reset display-window size parameters.  */
  winWidth = newWidth;
  winHeight = newHeight;
}

void mouseActionFunc(GLint button, GLint action, GLint xMouse, GLint yMouse)
{
	if(userMode == 0){

		if (button == GLUT_RIGHT_BUTTON && action == GLUT_DOWN && interval  == 0){
			interval = 3;
		}
		else if (button == GLUT_LEFT_BUTTON && action == GLUT_DOWN && interval  == 3){
					interval = 0;
		}

		else if (button == GLUT_LEFT_BUTTON && action == GLUT_DOWN && interval == 0) { // Create object.
			 mouseMovement[0].x = xMouse;
			 mouseMovement[0].y = winHeight - yMouse;
			 mouseMovement[1].x = xMouse;
			 mouseMovement[1].y = winHeight - yMouse;
			 interval = 1;
			 objectCount += 1;
			 moveNodeFront(&startObj, &endObj, newNode(mouseMovement,drawMode, outlineColor, fillColor, strokeWidthValue),0);



		}


	  else if(button == GLUT_LEFT_BUTTON && action == GLUT_UP && interval == 1){
		  mouseMovement[1].x = xMouse;
		  mouseMovement[1].y = winHeight - yMouse;
		  if(drawMode == 1){


		  if(mouseMovement[0].x > mouseMovement[1].x){
			  int temp = mouseMovement[0].x;
			  mouseMovement[0].x = mouseMovement[1].x;
			  mouseMovement[1].x = temp;
		  }
		  if(mouseMovement[0].y > mouseMovement[1].y){
			  int temp = mouseMovement[0].y;
			  mouseMovement[0].y = mouseMovement[1].y;
			  mouseMovement[1].y = temp;
		  }
		  }
	 	 	// moveNodeFront(&startObj, &endObj, newNode(mouseMovement,drawMode, outlineColor, fillColor, strokeWidthValue),0);
	 	 	 interval = 0;
			 display();
	  }
	}

	if (userMode == 1){					// Edit mode
		if(button == GLUT_LEFT_BUTTON && action == GLUT_DOWN && interval == 0){
			mouseMovement[0].x = xMouse;
			mouseMovement[0].y = winHeight - yMouse;
			mouseMovement[1].x = xMouse;
			mouseMovement[1].y = winHeight - yMouse;
			objExists = selectNode(&startObj, &endObj, currentObj,mouseMovement);
			if(objExists > objectCount){
				userMode = 0;
			}
			else{
				interval = 1;

			}
		}

		else if(button == GLUT_LEFT_BUTTON && action == GLUT_DOWN && moveMode == 1 && interval == 2){
			mouseMovement[0].x = xMouse;
			mouseMovement[0].y = winHeight - yMouse;
			interval = 3;
		}
		else if(button == GLUT_LEFT_BUTTON && action == GLUT_UP && moveMode == 1 && interval == 3){

			objExists = 0;
			interval = 0;
			moveMode = 0;
			userMode = 0;
		}

	}
  glFlush();
}

void mouseMotionFunc(GLint xMouse, GLint yMouse){
	if(userMode == 0 && interval == 1){
		mouseMovement[1].x = xMouse;
		mouseMovement[1].y = winHeight - yMouse;
		outlineNode(&startObj, &endObj, mouseMovement,1);

	}
	else if(userMode == 1 && interval == 3 && objExists != 0){
		int xMove = mouseMovement[0].x - xMouse;
		int yMove = mouseMovement[0].y - (winHeight - yMouse);

		moveNodeAround(&startObj,&endObj,xMove,yMove,objExists);
		mouseMovement[0].x = xMouse;
		mouseMovement[0].y = winHeight - yMouse;
		mouseMovement[1].x = xMouse;
		mouseMovement[1].y = winHeight - yMouse;

	}
	glutPostRedisplay();
	glFlush();
}

int main(int argc, char** argv) {


	glutInit(&argc, argv);                         // Initialize GLUT.
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);   // Set display mode.
	glutInitWindowPosition(50, 100);    // Set top-left display-window position.
	glutInitWindowSize(800, 600);        // Set display-window width and height.
	window = glutCreateWindow("SimpleDraw (Terry Tran)");        // Create display window.
	init();                                 // Execute initialization procedure.


	addMenu();
	glutDisplayFunc(display);          // Send graphics to display window.
	glutReshapeFunc(winReshapeFcn);
	glutMouseFunc(mouseActionFunc);
	glutMotionFunc(mouseMotionFunc);
	glutMainLoop( );
}
