/*
 * menu.hpp
 *
 *  Created on: 2021 Oct 4
 *      Author: Terry
 */

#ifndef MENU_HPP_
#define MENU_HPP_


#include <GL/glut.h>

#endif /* MENU_HPP_ */


//* menu design
void mainMenu(GLint renderingOption);

/*  Set fill color values according to the submenu option selected.  */
void fillColorSubMenu(GLint colorOption);

/*  Set outline color values according to the submenu option selected.  */
void outlineColorSubMenu(GLint colorOption);

/*  Set shape value according to the submenu option selected.  */
void drawSubMenu(GLint shapeOption);

/*  Set width value according to the submenu option selected.  */
void widthSubMenu(GLint widthOption);

/* Edit*/
void editMenu(GLint editOption);

/* File*/
void fileMenu(GLint fileOption);

void addMenu();
