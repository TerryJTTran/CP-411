/*
 * file.cpp
 *
 *  Created on: 2021 Oct 4
 *      Author: Terry
 */

#include "object.hpp"

#define GL_BGR_EXT 0x80E0
#define GL_BGR     0x80E0
#define GL_BGRA    0x80E1


int saveBitmap(const char *ptrcFileName, int nX, int nY, int nWidth, int nHeight)
{
	FILE *fp = fopen(ptrcFileName, "wb");
	if (fp == NULL) {
		printf("fp == NULL \n");
		return 0;
	}
		printf("step 1\n");

	// allocate memory to store image data
	int bitsize = nWidth*nHeight*3 +  ((3*nWidth)%4 == 0 ? 0 : (4-(3*nWidth)%4)*nHeight);

	printf("step 0 %d\n", bitsize);

	unsigned char *ptrImage = (unsigned char*) malloc(bitsize);
	if (ptrImage == NULL) {
		printf("ptrImage == NULL \n");
		fclose(fp);
		return 0;
	}

	//read pixels from frame buffer, byte order is BGR
	glReadPixels(nX, nY, nWidth, nHeight, GL_BGR, GL_UNSIGNED_BYTE, ptrImage);

	printf("step 1\n");
	// clean memory buffer of bitmap header and information header
	BITMAPFILEHEADER bfh;
	BITMAPINFOHEADER bih;
	memset(&bfh, 0, sizeof(bfh));
	memset(&bih, 0, sizeof(bih));

	// set the bitmap header with the give parameters
	bfh.bfType = 0x4d42; // 'MB'
	bfh.bfSize = sizeof(bfh) + sizeof(bih) + bitsize;
	bfh.bfOffBits = sizeof(bfh) + sizeof(bih);

    // set bitmap information header
	bih.biSize = sizeof(bih);
	bih.biWidth = nWidth + nWidth%4;
	bih.biHeight = nHeight;
	bih.biPlanes = 1;
	bih.biBitCount = 24;
	bih.biSizeImage = bitsize;

		printf("step 2\n");
	// write to file
	if (fwrite(&bfh, sizeof(bfh), 1, fp) < 1) {
		free(ptrImage);
		fclose(fp);
		return 0;
	};

	if (fwrite(&bih, sizeof(bih), 1, fp)<1) {
		free(ptrImage);
		fclose(fp);
		return 0;
	}

	printf("step 3\n");

	if ( fwrite(ptrImage, 1, bitsize, fp) < bitsize ) {
		free(ptrImage);
		fclose(fp);
		return 0;
	}

	fclose(fp);
	free(ptrImage);

	printf("end of save bitmap\n");
	return 1;
}



void svgSave(node **startNode, node **endNode, int objectCount) {

		FILE* fp = fopen("output.svg","wb");


		node *tempObj = (node*) malloc(sizeof(node));
		tempObj = *endNode;

		fwrite("<?xml version=\"1.0\" standalone=\"no\"?>\n",sizeof(char),sizeof("<?xml version=\"1.0\" standalone=\"no\"?>\n"),fp);
		fwrite("<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">",sizeof(char),sizeof("<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">"),fp);
		fwrite("\n",sizeof(char),sizeof("\n"),fp);
		fwrite("<svg width=\"800\" height=\"600\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\">\n",sizeof(char),sizeof("<svg width=\"800\" height=\"600\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\">\n"),fp);

		for(int i = 1; i <= objectCount;i++){
			char aChar[4];
			char bChar[2];
			if(tempObj->shape == 0){
				fwrite("<circle cx=\"",sizeof(char),sizeof("<circle cx=\""),fp);
				itoa(tempObj->list[0].x,aChar,10);
				fwrite(aChar,sizeof(char),sizeof(aChar),fp);
				fwrite("\" cy=\"",sizeof(char),sizeof("\" cy=\""),fp);

				itoa(600 - tempObj->list[0].y,aChar,10);
				fwrite(aChar,sizeof(char),sizeof(aChar),fp);
				fwrite("\" r=\"",sizeof(char),sizeof("\" r=\""),fp);

				itoa((sqrt(pow((tempObj->list[0].y - tempObj->list[1].y),2) + pow((tempObj->list[0].x - tempObj->list[1].x),2))),aChar,10);
				fwrite(aChar,sizeof(char),sizeof(aChar),fp);
				}
			else{
				fwrite("<rect x=\"",sizeof(char),sizeof("<rect x=\""),fp);

				itoa(tempObj->list[0].x,aChar,10);
				fwrite(aChar,sizeof(char),sizeof(aChar),fp);
				fwrite("\" y=\"",sizeof(char),sizeof("\" y=\""),fp);

				itoa((600 - tempObj->list[0].y - (tempObj->list[1].y - tempObj->list[0].y)),aChar,10);
				fwrite(aChar,sizeof(char),sizeof(aChar),fp);
				fwrite("\" width=\"",sizeof(char),sizeof("\" width=\""),fp);

				itoa((tempObj->list[1].x - tempObj->list[0].x),aChar,10);
				fwrite(aChar,sizeof(char),sizeof(aChar),fp);
				fwrite("\" height=\"",sizeof(char),sizeof("\" height=\""),fp);

				itoa((tempObj->list[1].y - tempObj->list[0].y),aChar,10);
				fwrite(aChar,sizeof(char),sizeof(aChar),fp);
				}
			if(tempObj->outColor == 0){
				fwrite("\" stroke=\"blue\" stroke-width=\"",sizeof(char),sizeof("\" stroke=\"blue\" stroke-width=\""),fp);
			}
			else if(tempObj->outColor == 1){
				fwrite("\" stroke=\"green\" stroke-width=\"",sizeof(char),sizeof("\" stroke=\"green\" stroke-width=\""),fp);
				}
			else if(tempObj->outColor == 2){
				fwrite("\" stroke=\"red\" stroke-width=\"",sizeof(char),sizeof("\" stroke=\"red\" stroke-width=\""),fp);
				}
			else if(tempObj->outColor == 3){
				fwrite("\" stroke=\"black\" stroke-width=\"",sizeof(char),sizeof("\" stroke=\"black\" stroke-width=\""),fp);
				}
			else if(tempObj->outColor == 4){
				fwrite("\" stroke=\"white\" stroke-width=\"",sizeof(char),sizeof("\" stroke=\"white\" stroke-width=\""),fp);
				}
			else if(tempObj->outColor == 5){
				fwrite("\" stroke=\"purple\" stroke-width=\"",sizeof(char),sizeof("\" stroke=\"purple\" stroke-width=\""),fp);
				}
			else if(tempObj->outColor == 6){
				fwrite("\" stroke=\"cyan\" stroke-width=\"",sizeof(char),sizeof("\" stroke=\"cyan\" stroke-width=\""),fp);
				}
			else{
				fwrite("\" stroke=\"yellow\" stroke-width=\"",sizeof(char),sizeof("\" stroke=\"yellow\" stroke-width=\""),fp);
				}

			itoa(tempObj->strokeWidth,bChar,10);
			fwrite(bChar,sizeof(char),sizeof(bChar),fp);
			if(tempObj->filColor == 0){
				fwrite(" \" fill=\"blue\"/>\n",sizeof(char),sizeof(" \" fill=\"blue\"/>\n"),fp);
				}
			else if(tempObj->filColor == 1){
				fwrite(" \" fill=\"green\"/>\n",sizeof(char),sizeof(" \" fill=\"green\"/>\n"),fp);
				}
			else if(tempObj->filColor == 2){
				fwrite(" \" fill=\"red\"/>\n",sizeof(char),sizeof(" \" fill=\"red\"/>\n"),fp);
				}
			else if(tempObj->filColor == 3){
				fwrite(" \" fill=\"black\"/>\n",sizeof(char),sizeof(" \" fill=\"black\"/>\n"),fp);
				}
			else if(tempObj->filColor == 4){
				fwrite(" \" fill=\"white\"/>\n",sizeof(char),sizeof(" \" fill=\"white\"/>\n"),fp);
				}
			else if(tempObj->filColor == 5){
				fwrite(" \" fill=\"purple\"/>\n",sizeof(char),sizeof(" \" fill=\"purple\"/>\n"),fp);
				}
			else if(tempObj->filColor == 6){
				fwrite(" \" fill=\"cyan\"/>\n",sizeof(char),sizeof(" \" fill=\"cyan\"/>\n"),fp);
				}
			else{
				fwrite(" \" fill=\"yellow\"/>\n",sizeof(char),sizeof(" \" fill=\"yellow\"/>\n"),fp);
				}
			tempObj = tempObj->prev;
		}
		fwrite("</svg>",sizeof(char),sizeof("</svg>"),fp);
		fclose(fp);
		printf("\nWhen using svgOpen, it is required to open the svg file in an editor like notepad and saving.\n");
		return;
}

int svgOpen(node **startNode, node **endNode, int objectCount){

	FILE* fp = fopen("output.svg","r");

	char buffer[200];
	char *token;

	point list[2];
	int shape;
	int outColor;
	int filColor;
	int strokeWidth;

	if (fp == NULL){
		perror("Error opening file");
	}
	else{
		fgets(buffer,200,fp);
		printf("%s\n",buffer);
		fgets(buffer,200,fp);
		printf("%s\n",buffer);
		fgets(buffer,200,fp);
		printf("%s\n",buffer);

		while(! feof(fp)){
			fgets(buffer,200,fp);
			token = strtok(buffer,"\"");

			if(strcmp(token," <rect x=") == 0){
				shape = 1;
				token = strtok(NULL,"\"");
				list[0].x = atoi(token);
				token = strtok(NULL,"\"");
				token = strtok(NULL,"\"");
				list[0].y = atoi(token);

				token = strtok(NULL,"\"");
				token = strtok(NULL,"\"");
				list[1].x = list[0].x + atoi(token);
				token = strtok(NULL,"\"");
				token = strtok(NULL,"\"");
				list[1].y = list[0].y + atoi(token);
			}
			else if (strcmp(token," <circle cx=") == 0){
				shape = 0;
				token = strtok(NULL,"\"");
				list[0].x = atoi(token);
				token = strtok(NULL,"\"");
				token = strtok(NULL,"\"");
				list[0].y = atoi(token);

				token = strtok(NULL,"\"");
				token = strtok(NULL,"\"");
				list[1].x = list[0].x + atoi(token);
				list[1].y = list[0].y;
			}
			else{
				fclose(fp);
				break;
			}

			token = strtok(NULL,"\"");
			token = strtok(NULL,"\"");
			if(strcmp(token,"blue") == 0){
				outColor = 0;
			}
			else if(strcmp(token,"green") == 0){
				outColor = 1;
			}
			else if(strcmp(token,"red") == 0){
				outColor = 2;
			}
			else if(strcmp(token,"black") == 0){
				outColor = 3;
			}
			else if(strcmp(token,"white") == 0){
				outColor = 4;
			}
			else if(strcmp(token,"purple") == 0){
				outColor = 5;
			}
			else if(strcmp(token,"cyan") == 0){
				outColor = 6;
			}
			else{				//Yellow.
				outColor = 7;
			}

			token = strtok(NULL,"\"");
			token = strtok(NULL,"\"");
			strokeWidth = atoi(token);

			token = strtok(NULL,"\"");
			token = strtok(NULL,"\"");
			if(strcmp(token,"blue") == 0){
				filColor = 0;
			}
			else if(strcmp(token,"green") == 0){
				filColor = 1;
			}
			else if(strcmp(token,"red") == 0){
				filColor = 2;
			}
			else if(strcmp(token,"black") == 0){
				filColor = 3;
			}
			else if(strcmp(token,"white") == 0){
				filColor = 4;
			}
			else if(strcmp(token,"purple") == 0){
				filColor = 5;
			}
			else if(strcmp(token,"cyan") == 0){
				filColor = 6;
			}
			else{				//Yellow.
				filColor = 7;
			}

			token = strtok(NULL,"\"");
			objectCount += 1;
			moveNodeFront(*(&startNode),*(&endNode),newNode(list,shape,outColor,filColor,strokeWidth),0);
			memset(buffer,0,sizeof(buffer));
		}
	}

	fclose(fp);
	return objectCount;
}
