/*
 *  SimpleView : reference design
 *  Author: HBF
 *  Version: 2021-10-15 (update)
 */
#include "Light.hpp"
#include "Matrix.hpp"
#include <stdio.h>


Light::Light(){
	mc.mat[0][3] = 1.5;
	mc.mat[1][3] = 1.5;
	mc.mat[2][3] = 1.5;

	I = 1.0;
	Rd = 1.0;
	on = true;
	size = 0.2;
}

void Light::Reset(){
	I = 1.0;
	Rd = 1.0;
	on = true;
	size = 0.2;
}

void Light::rotate(GLfloat rx, GLfloat ry, GLfloat rz, GLfloat angle){ //w.r.p.t WC
	Matrix m;
	m.rotateMatrix(rx, ry, rz, angle);
	GLfloat vector[4];
	vector[0] = mc.mat[0][3];
	vector[1] = mc.mat[1][3];
	vector[2] = mc.mat[2][3];
	vector[3] = 1;
	m.multiplyVector(vector);
	mc.mat[0][3] = vector[0];
	mc.mat[1][3] = vector[1];
	mc.mat[2][3] = vector[2];
}

void Light::translate(GLfloat tx, GLfloat ty, GLfloat tz){ //w.r.p.t WC
	mc.mat[0][3] += tx;
	mc.mat[1][3] += ty;
	mc.mat[2][3] += tz;
}

void Light::Increment(GLfloat p){
// change light intensity
	I += p;
	if (I < 0.03) I = 0.01;
	else if (I > 0.97 ) I = 1;
}

void Light::draw(){
	if(on == true){
		glPushMatrix();
		this->ctmMultiply();
// draw a sphere as light
		glColor3f(I, I, I);
		glTranslatef(mc.mat[0][3],mc.mat[1][3],mc.mat[2][3]);
		glutSolidSphere(size, 10, 10);
		//glScalef(s, s, s);

		glPopMatrix();
	}
}
