#include "Sphere.hpp"

extern RenderMode renderMode;

Sphere::Sphere(GLdouble size) {
	radius = size;
	splices = 50;
	stacks = 50;
	textureID = 0;
	r=1;
	g=1;
	b=1;
	quad = gluNewQuadric();
}

void Sphere::draw() {
	glPushMatrix();
	ctmMultiply();

	switch (renderMode) {
		case WIRE:
		case CONSTANT:
		case FLAT:
		case SMOOTH:
			glColor3f(r, g, b);
			glutSolidSphere(radius,splices,stacks);
			break;

		case TEXTURE:
			// your code
			gluQuadricDrawStyle(quad, GLU_FILL);
			gluQuadricTexture(quad, GL_TRUE);
			gluQuadricNormals(quad, GLU_SMOOTH);
			glShadeModel(GL_FLAT);
			glEnable(GL_TEXTURE_2D);
			glRotatef(0, 0.0, 1.0, 0.0);
			glBindTexture(GL_TEXTURE_2D, textureID);
			glRotatef(0, 1.0, 0.0, 1.0);
			gluSphere(quad, radius, splices, stacks);
			glDisable(GL_TEXTURE_2D);
			glPopMatrix();
			break;

		case PHONE:
			// your code
			break;
	}

	glPopMatrix();
}


