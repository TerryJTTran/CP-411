Name: Terry Tran (type your name here)
ID: 190199810
Email: tran9810@mylaurier.ca
WorkID: cp411-a5
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: Q -- Question, T -- Lab tasks, R -- Project requirements
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Evaluation grid: [self-evaluation/total/marker-evaluation]

A5

Q1 Curve and surface computing

Q1.1 Cubic spline computing               [5/5/*]
Q1.2 Rotation surface and normal          [5/5/*]

Q2 Curve, surface, texture, GLSL

Q2.1 Curve model and rendering            [5/5/*]
Q2.2 Surface model and rendering          [5/5/*]
Q2.3 Texture mapping                      [5/5/*]
Q2.4 GPU programming by GLSL              [5/5/*]

Q3 SimpleView3 - texture, GLSL, curve, and surface

Q3.1 Texture mapping basics               [10/10/*]
Q3.2 Solar system with texture mapping    [10/10/*]
Q3.3 Bezier curve                         [20/20/*]
Q3.4 Rotation surface of Bezier curve     [20/20/*]
Q3.5 Phong shading by GLSL                [10/10/*]
Q3.6 My Graphics Library                  [0/0/*]

Total:                                    [100/100/*]